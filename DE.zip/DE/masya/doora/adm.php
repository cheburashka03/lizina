<?php
  session_start();

  if(empty($_SESSION['auth'])) {
      header("Location: index.php");
  }

$link = mysqli_connect('localhost', 'root', '', 'doors');
$counter = mysqli_query($link, "SELECT COUNT(*) as count FROM zakazi WHERE status = 'выполнен'");
$rab = mysqli_query($link, "SELECT COUNT(*) as count FROM zakazi WHERE type = 'межкомнатная'");
$rabs = mysqli_query($link, "SELECT COUNT(*) as count FROM zakazi WHERE type = 'входная'");

$res = mysqli_fetch_assoc($counter);
$reb = mysqli_fetch_assoc($rab);
$rebs = mysqli_fetch_assoc($rabs);

$count1 = $res['count'];
$count2 = $reb['count'];
$count3 = $rebs['count'];

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Техносервис</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
<header><h1>ООО Мир дверей - я еврей</h1>
    <nav>
			<ul>
        <li><a href="/index.php">Главная</a></li>
        <li><a href="/update_worker.php">Изменить исполнителя</a></li>
        <li><a href="/update.php">Изменить статус заказа</a></li>
				<li><a href="/update_zakaz.php">Изменить описание заказа</a></li>
        <li><a href="/logout.php">Выход</a></li>
				</ul>
    </nav>
	</header>
    <main>
			<h2>Панель администратора</h2>
			<p>Кол-во выполненных заявок: <? echo $count1?></p>
			<p>Кол-во установленных межкомнатных дверей: <? echo $count2?></p>
			<p>Кол-во установленных входных дверей: <? echo $count3?></p>

        <h2>Поиск заявки</h2>
        <form method="POST">
            <label>Введите ФИО клиента</label>
            <input type="text" name="fio">
            <button>Найти</button>
        </form>
        <h2>Все заявки</h2>
            <table>
                <tr>
                   <th>Номер заявки</th>
                   <th>Дата добавления</th>
                   <th>Тип двери</th>
                   <th>Описание заказа</th>
                   <th>Фио клиента</th>
                   <th>Номер заказчика</th>
                   <th>Адрес заказчика</th>
									 <th>Статус заказа</th>
									 <th>Исполнитель</th>
                </tr>
<?
                $link = mysqli_connect('localhost', 'root', '', 'doors');

                if(!empty($_POST['fio'])){
                    $search = mysqli_query($link, ("SELECT * FROM zakazi WHERE fio = '$_POST[fio]'"));
                    while($res = mysqli_fetch_assoc($search)){
                        echo "<tr>
                        <td>$res[id]</td>
                        <td>$res[date]</td>
                        <td>$res[type]</td>
                        <td>$res[opisanie]</td>
                        <td>$res[fio]</td>
                        <td>$res[number]</td>
												<td>$res[adress]</td>
                        <td>$res[status]</td>
												<td>$res[worker]</td>
                        <tr>";   
                    }
                }else{


                $result = mysqli_query($link, ('SELECT * FROM zakazi'));

                while($row = mysqli_fetch_assoc($result)){
                    echo "<tr>
                    <td>$row[id]</td>
                    <td>$row[date]</td>
                    <td>$row[type]</td>
                    <td>$row[opisanie]</td>
                    <td>$row[fio]</td>
                    <td>$row[number]</td>
										<td>$row[adress]</td>
                    <td>$row[status]</td>
										<td>$row[worker]</td>
                    <tr>";
                }
            }
?>
            </table>
    </main>

</body>
</html>