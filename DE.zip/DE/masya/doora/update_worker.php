<?php
  session_start();

  if(empty($_SESSION['auth'])) {
      header("Location: index.php");
  }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мир дверей - я еврей</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
<header><h1>ООО Мир дверей - я еврей</h1>
    <nav>
			<ul>
        <li><a href="/index.php">Главная</a></li>
        <li><a href="/update_worker.php">Изменить исполнителя</a></li>
        <li><a href="/update.php">Изменить статус заказа</a></li>
				<li><a href="/update_zakaz.php">Изменить описание заказа</a></li>
        <li><a href="/logout.php">Выход</a></li>
				</ul>
    </nav>
	</header>
    <main>
			<h2>Добавить или изменить исполнителя заказа</h2>
        <form class="form1" action="" method="POST">
					<table>
						<tr>
							<td>Номер заявки</td>
							<td><input type="text" name="id"></td>
							</tr>
							<tr>
						<td>Назначить исполнителя заявки</td>
						<td><input type="text" name="worker"></td>
						</tr>
					</table>
					<button>Изменить</button>
        </form>
				<?
				$link = mysqli_connect('localhost', 'root', '', 'doors');

				if(!empty($_POST['id']) && !empty($_POST['worker'])){
					$id = $_POST['id'];
					$worker = $_POST['worker'];
					$result = mysqli_query($link, "UPDATE zakazi SET worker = '$worker' WHERE id = '$id'");
					if($result == 'true'){
						header("Location: adm.php");
					} else {
						echo "Ошибка =(";
					}
				}else{
					echo '<script> alert("заполните все поля")</script>';
				}
?>
</main>

</body>
</html>