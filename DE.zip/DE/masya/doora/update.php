<?php
  session_start();

  if(empty($_SESSION['auth'])) {
      header("Location: index.php");
  }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Техносервис</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
<header><h1>ООО Мир дверей - я еврей</h1>
    <nav>
			<ul>
        <li><a href="/index.php">Главная</a></li>
        <li><a href="/update_worker.php">Изменить исполнителя</a></li>
        <li><a href="/update.php">Изменить статус заказа</a></li>
				<li><a href="/update_zakaz.php">Изменить описание заказа</a></li>
        <li><a href="/logout.php">Выход</a></li>
				</ul>
    </nav>
	</header>
    <main>
			<h2>Изменить статус заявки</h2>
        <form class="form1" action="" method="POST">
					<table>
						<tr>
							<td>Номер заказа</td>
							<td><input type="text" name="id"></td>
							</tr>
							<tr>
						<td>Сменить статус заявки</td>
						<td><select name = "status">
						<option value = "сформирован">сформирован</option>
						<option value = "в обрботке">в обработке</option>
						<option value = "выполнен">выполнен</option>
						<select></td>
						</tr>
						</table>
						<button>Изменить</button>
        </form>
				<?
				$link = mysqli_connect('localhost', 'root', '', 'doors');

				if(!empty($_POST['id']) && !empty($_POST['status'])){
					$id = $_POST['id'];
					$status = $_POST['status'];
					$result = mysqli_query($link, "UPDATE zakazi SET status = '$status' WHERE id = '$id'");
					if($result == 'true'){
						header("Location: adm.php");
					} else {
						echo "Ошибка =(";
					}
				}else{
					echo '<script> alert("заполните все поля")</script>';
				}
?>
</main>

</body>
</html>