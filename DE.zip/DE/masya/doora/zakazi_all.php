<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>кто</title>
	<link rel="stylesheet" href="styl.css">
</head>
<body>
<header><h1>ООО Мир дверей - я еврей</h1>
    <nav>
			<ul>
        <li><a href="/index.php">Главная</a></li>
        <li><a href="/zakazi.php">Подать заявку</a></li>
        <li><a href="/zakazi_all.php">Все заявки</a></li>
        <li><a href="/logout.php">Выход</a></li>
				</ul>
    </nav>
	</header>
    <main>
        <h2>Поиск заказа</h2>
        <form method="POST">
            <label>Введите ФИО заказчика</label>
            <input type="text" name="fio">
            <button>Найти</button>
        </form>
        <h2>Все заявки</h2>
            <table>
                <tr>
                   <th>Номер заказа</th>
                   <th>Дата добавления</th>
                   <th>Тип двери</th>
                   <th>Описание заказа</th>
                   <th>Фио заказчика</th>
                   <th>Номер заказчика</th>
									 <th>Адрес заказчика</th>
                   <th>Статус заказа</th>
                </tr>
<?
                $link = mysqli_connect('localhost', 'root', '', 'doors');

                if(!empty($_POST['fio'])){
                    $search = mysqli_query($link, ("SELECT * FROM zakazi WHERE fio = '$_POST[fio]'"));
                    while($res = mysqli_fetch_assoc($search)){
                        echo "<tr>
                        <td>$res[id]</td>
                        <td>$res[date]</td>
                        <td>$res[type]</td>
                        <td>$res[opisanie]</td>
                        <td>$res[fio]</td>
                        <td>$res[number]</td>
												<td>$res[adress]</td>
                        <td>$res[status]</td>
                        <tr>";   
                    }
                }else{


                $result = mysqli_query($link, ('SELECT * FROM zakazi'));

                while($row = mysqli_fetch_assoc($result)){
                    echo "<tr>
                    <td>$row[id]</td>
                    <td>$row[date]</td>
                    <td>$row[type]</td>
                    <td>$row[opisanie]</td>
                    <td>$row[fio]</td>
                    <td>$row[number]</td>
										<td>$row[adress]</td>
                    <td>$row[status]</td>
                    <tr>";
                }
            }
?>

            </table>
    </main>
</body>
</html>