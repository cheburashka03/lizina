<?php
    session_start();

    if(empty($_SESSION['auth'])) {
        header("Location: index.php");
    }
?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="styl.css">
</head>
<body>
<header><h1>ООО Мир дверей - я еврей</h1>
    <nav>
			<ul>
        <li><a href="/index.php">Главная</a></li>
        <li><a href="/zakazi.php">Подать заявку</a></li>
        <li><a href="/zakazi_all.php">Все заявки</a></li>
        <li><a href="/logout.php">Выход</a></li>
				</ul>
    </nav>
	</header>
<main>
        <h2>Подать заявку</h2>
        <form class="form1" action="" method="POST">
            <table>
                <tr>
								<td>Тип двери</td>
						<td><select name = "type">
						<option value = "межкомнатная">Межкомнатная</option>
						<option value = "входная">Входная</option>
						<select></td>
                </tr>
                <tr>
                    <td>Описание заказа</td>
                    <td><textarea name="opisanie"></textarea></td>
                </tr>
                <tr>
                    <td>Фио клиента</td>
                    <td><input type="text" name = "fio"></td>
                </tr>
                <tr>
                    <td>Контактный номер клиента</td>
                    <td><input type="text" name="number"></td>
                </tr>
                <tr>
								<tr>
                    <td>Адрес</td>
                    <td><input type="text" name="adress"></td>
                </tr>
								<br>
            </form>
            </table>
						<button>Добавить</button>
    </main>

<?
    $link = mysqli_connect('localhost', 'root', '', 'doors');
    if(!empty($_POST['type']) && !empty($_POST['opisanie']) && !empty($_POST['fio']) && !empty($_POST['number']) && !empty($_POST['adress'])) {
        $type = $_POST['type'];
        $opisanie = $_POST['opisanie'];
        $fio = $_POST['fio'];
				$number = $_POST['number'];
				$adress = $_POST['adress'];

        $result = mysqli_query($link, "INSERT INTO zakazi(type, opisanie, fio, number, adress) VALUES ('$type', '$opisanie', '$fio', '$number', '$adress')");
        if($result == 'true'){
                header("Location: zakazi_all.php");
            }else{
                echo '<script>alert("Ошибка с бд =( ")</script>';
            }   
        }else{
            echo '<script>alert("Заполните все поля")</script>';
        }
?>


</body>
</html>