<?php
session_start();

$link = mysqli_connect('localhost','root','','doors');


if(!empty($_POST['login']) && !empty($_POST['password'])){
	$login = $_POST['login'];
	$password = md5($_POST['password']);

	$result = mysqli_query($link, "SELECT * FROM users WHERE login = '$login' AND password = '$password'");
	$user = mysqli_fetch_assoc($result);
	
	if(!empty($user)) {
		$_SESSION['auth'] = true;
		$_SESSION['login'] = $user['login'];
		$_SESSION['status'] = $user['status'];
		if($_SESSION['status'] == '0'){
			header("Location: zakazi.php");
		}elseif($_SESSION['status'] == '1'){
			header("Location: adm.php");
		}}else{
	echo '<script>alert("Неверный логин или пароль")</script>';}
		}


?>




<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="styl.css">
</head>
<body>
		<header>
			<h1>ООО Мир дверей - я еврей</h1>
		</header>
	<main>
		<h2>Авторизация</h2>
		<form method="POST" class="form">
			<label for="textfield">Логин</label>
			<input type="text" name="login" id="textField">
			<br><br>
			<label for="passfield">Пароль</label>
			<input type="password" name="password" id="passField">
			<br><br>
			<button class="button1">Войти</button>
		</form>
	</main>
</body>
</html>