<?php
  session_start();

  if(empty($_SESSION['auth'])) {
      header("Location: index.php");
  }
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Техносервис</title>
    <link rel="stylesheet"type="text/css" href="style.css">
</head>
<body>
    <header>ООО Техносервис</header>
    <nav>
				<a href="/index.php">Главная</a>
        <a href="/update_worker.php">Изменить исполнителя</a>
        <a href="/update.php">Изменить статус заявки</a>
				<a href="/update_problem.php">Изменить описание заявки</a>
        <a href="/logout.php">Выход</a>
    </nav>
    <main>
			<h2>Добавить или изменить исполнителя заявки</h2>
        <form class="form1" action="" method="POST">
					<table>
						<tr>
							<td>Номер заявки</td>
							<td><input type="text" name="id"></td>
							</tr>
							<tr>
						<td>Назначить исполнителя заявки</td>
						<td><input type="text" name="worker"></td>
						</tr>
						<tr>
						<td></td>
						<td><button>Изменить</button></td>
					</tr>
        </form>
				<?
				$link = mysqli_connect('localhost', 'root', '', 'tehno');

				if(!empty($_POST['id']) && !empty($_POST['worker'])){
					$id = $_POST['id'];
					$worker = $_POST['worker'];
					$result = mysqli_query($link, "UPDATE problems SET worker = '$worker' WHERE id = '$id'");
					if($result == 'true'){
						header("Location: adm.php");
					} else {
						echo "Ошибка =(";
					}
				}else{
					echo 'заполните все поля';
				}
?>
</main>

</body>
</html>