<?php
    session_start();

    if(empty($_SESSION['auth'])) {
        header("Location: index.php");
    }
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Техносервис</title>
    <link rel="stylesheet"type="text/css" href="style.css">
</head>
<body>
    <header>ООО Техносервис</header>
    <nav>
        <a href="/index.php">Главная</a>
        <a href="/problems.php">Подать заявку</a>
        <a href="/problems_all.php">Все заявки</a>
        <a href="/logout.php">Выход</a>
    </nav>
    <main>
        <h2>Подать заявку</h2>
        <form class="form1" action="" method="POST">
            <table>
                <tr>
                    <td>Оборудование</td>
                    <td><input type="text" name="obroud"></td>
                </tr>
                <tr>
                    <td>Тип неисправности</td>
                    <td><input type="text" name="neispravnost"></td>
                </tr>
                <tr>
                    <td>Описание проблемы</td>
                    <td><textarea name = "opisanie"></textarea></td>
                </tr>
                <tr>
                    <td>ФИО клиента</td>
                    <td><input type="text" name="fio"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><button>Отправить</button></td>
                </tr>
            </form>
            </table>
    </main>

    <?
    $link = mysqli_connect('localhost', 'root', '', 'tehno');
    if(!empty($_POST['obroud']) && !empty($_POST['neispravnost']) && !empty($_POST['opisanie']) && !empty($_POST['fio'])) {
        $obroud = $_POST['obroud'];
        $neispravnost = $_POST['neispravnost'];
        $opisanie = $_POST['opisanie'];
        $fio = $_POST['fio'];

        $result = mysqli_query($link, "INSERT INTO problems(obroud, neispravnost, opisanie, fio) VALUES ('$obroud', '$neispravnost', '$opisanie', '$fio')");
        if($result == 'true'){
                header("Location: problems_all.php");
            }else{
                echo '<script>alert("Ошибка с бд =( ")</script>';
            }   
        }else{
            echo '<script>alert("Информация не добавлена")</script>';
        }
?>

</body>
</html>