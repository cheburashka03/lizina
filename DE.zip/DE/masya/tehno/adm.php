<?php
  session_start();

  if(empty($_SESSION['auth'])) {
      header("Location: index.php");
  }

$link = mysqli_connect('localhost', 'root', '', 'doors');
$counter = mysqli_query($link, "SELECT COUNT(*) as count FROM problems WHERE status = 'выполнено'");
$ojid = mysqli_query($link, "SELECT COUNT(*) as count FROM problems WHERE status = 'в ожидании'");
$rab = mysqli_query($link, "SELECT COUNT(*) as count FROM problems WHERE status = 'в работе'");

$res = mysqli_fetch_assoc($counter);
$rez = mysqli_fetch_assoc($ojid);
$ress = mysqli_fetch_assoc($rab);
$count1 = $res['count'];
$count2 = $rez['count'];
$count3 = $ress['count'];
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Техносервис</title>
    <link rel="stylesheet"type="text/css" href="style.css">
</head>
<body>
    <header>ООО Техносервис</header>
    <nav>
        <a href="/index.php">Главная</a>
        <a href="/update_worker.php">Изменить исполнителя</a>
        <a href="/update.php">Изменить статус заявки</a>
				<a href="/update_problem.php">Изменить описание заявки</a>
        <a href="/logout.php">Выход</a>
    </nav>
    <main>
			<h2>Панель администратора</h2>
			<p>Кол-во выполненных заявок: <? echo $count1?></p>
			<p>Кол-во необработанных заявок: <? echo $count2?></p>
			<p>Кол-во заявок в работе: <? echo $count3?></p>
        <h2>Поиск заявки</h2>
        <form method="POST">
            <label>Введите ФИО клиента</label>
            <input type="text" name="fio">
            <button>Найти</button>
        </form>
        <h2>Все заявки</h2>
            <table>
                <tr>
                   <th>Номер заявки</th>
                   <th>Дата добавления</th>
                   <th>Оборудование</th>
                   <th>Тип неисправности</th>
                   <th>Описание проблемы</th>
                   <th>ФИО клиента</th>
                   <th>Статус заявки</th>
									 <th>Исполнитель</th>
                </tr>
<?
                $link = mysqli_connect('localhost', 'root', '', 'doors');

                if(!empty($_POST['fio'])){
                    $search = mysqli_query($link, ("SELECT * FROM zakazi WHERE fio = '$_POST[fio]'"));
                    while($res = mysqli_fetch_assoc($search)){
                        echo "<tr>
                        <td>$res[id]</td>
                        <td>$res[date]</td>
                        <td>$res[type]</td>
                        <td>$res[opisanie]</td>
                        <td>$res[fio]</td>
                        <td>$res[number]</td>
												<td>$res[adress]</td>
                        <td>$res[status]</td>
                        <tr>";   
                    }
                }else{


                $result = mysqli_query($link, ('SELECT * FROM zakazi ORDER BY id DESC'));

                while($row = mysqli_fetch_assoc($result)){
                    echo "<tr>
                    <td>$row[id]</td>
                    <td>$row[date]</td>
                    <td>$row[type]</td>
                    <td>$row[opisanie]</td>
                    <td>$row[fio]</td>
                    <td>$row[number]</td>
										<td>$row[adress]</td>
                    <td>$row[status]</td>
                    <tr>";
                }
            }
?>
            </table>
    </main>

</body>
</html>