<?php
// Начинаем сессию
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных о заявках, назначенных мастеру
$master_id = $_SESSION["user_id"];
$sql = "SELECT * FROM orders WHERE responsible_employee = ?";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("i", $master_id);
    $stmt->execute();
    $orders_result = $stmt->get_result();
} else {
    $orders_result = false;
}

// Проверка новых уведомлений
$new_notifications = false;
$sql = "SELECT * FROM notifications WHERE user_id = ? AND is_read = 0";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("i", $master_id);
    $stmt->execute();
    $notifications_result = $stmt->get_result();
    if ($notifications_result->num_rows > 0) {
        $new_notifications = true;
    }
    $stmt->close();
} else {
    $notifications_result = false;
}

// Обработка обновления статуса заявки
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_status"])) {
    $order_id = $_POST["order_id"];
    $new_status = $_POST["new_status"];

    $sql = "UPDATE orders SET stage = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("si", $new_status, $order_id);
        if ($stmt->execute()) {
            $success_message = "Статус заявки успешно обновлен.";

            // Добавление уведомления для клиента
            $sql = "SELECT user_id FROM orders WHERE id = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                $stmt->bind_param("i", $order_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                $client_id = $row["user_id"];

                $sql = "INSERT INTO notifications (user_id, message, is_read) VALUES (?, ?, 0)";
                $message = "Статус вашей заявки обновлен: " . $new_status;
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("is", $client_id, $message);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        } else {
            $error_message = "Произошла ошибка при обновлении статуса заявки: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error_message = "Произошла ошибка при подготовке SQL-запроса.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Панель мастера</title>
</head>
<body>
    <h1>Панель мастера</h1>
    <?php if ($new_notifications) { ?>
        <p style="color: red;">У вас есть новые уведомления.</p>
    <?php } ?>
    <h2>Ваши заявки</h2>
    <table>
        <tr>
            <th>Номер заявки</th>
            <th>Этап</th>
            <th>Описание проблемы</th>
            <th>Комментарий</th>
            <th>Запчасти и материалы</th>
            <th>Действие</th>
        </tr>
        <?php
        if ($orders_result && $orders_result->num_rows > 0) {
            while($row = $orders_result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["order_number"] . "</td>";
                echo "<td>" . $row["stage"] . "</td>";
                echo "<td>" . $row["problem_description"] . "</td>";
                echo "<td>" . $row["comment"] . "</td>";
                echo "<td>" . $row["parts_and_materials"] . "</td>";
                echo "<td>";

                echo "<form method='post' action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "'>";
                echo "<input type='hidden' name='order_id' value='" . $row["id"] . "'>";
                echo "<select name='new_status'>";
                echo "<option value='in_progress'>In Progress</option>";
                echo "<option value='ready_for_pickup'>Ready for Pickup</option>";
                echo "</select>";
                echo "<input type='submit' name='update_status' value='Update Status'>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>Нет заявок.</td></tr>";
        }
        ?>
    </table>
    <?php if (isset($success_message)) { ?>
        <p style="color: green;"><?php echo $success_message; ?></p>
    <?php } ?>
    <?php if (isset($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>
    <a href="index.php">Logout</a>
</body>
</html>
