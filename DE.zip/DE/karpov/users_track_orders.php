<?php
// Начинаем сессию
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение списка заявок
$sql = "SELECT * FROM orders";
$result = $conn->query($sql);

// Обработка поиска
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_query = $_POST["search_query"];
    $sql = "SELECT * FROM orders WHERE order_number LIKE '%$search_query%' OR problem_description LIKE '%$search_query%' OR responsible_employee LIKE '%$search_query%'";
    $result = $conn->query($sql);
}

// Проверка новых уведомлений
// Проверка новых уведомлений
$new_notifications = false;
if (isset($_SESSION["user_id"])) {
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = 0");
    if ($stmt) {
        $stmt->bind_param("i", $_SESSION["user_id"]);
        $stmt->execute();
        $notifications_result = $stmt->get_result();
        if ($notifications_result->num_rows > 0) {
            $new_notifications = true;
        }
        $stmt->close();
    } else {
        $notifications_result = false;
    }
} else {
    $notifications_result = false;
}



$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Отслеживание статуса заявок</title>
</head>
<body>
    <h1>Отслеживание статуса заявок</h1>
    <?php if ($new_notifications) { ?>
        <p style="color: red;">У вас есть новые уведомления о статусе заявок.</p>
    <?php } ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        Поиск: <input type="text" name="search_query" placeholder="Введите номер или описание заявки">
        <input type="submit" name="submit" value="Найти">
    </form>
    <table>
        <tr>
            <th>Номер заявки</th>
            <th>Этап</th>
            <th>Описание проблемы</th>
            <th>Ответственный</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["order_number"] . "</td>";
                echo "<td>" . $row["stage"] . "</td>";
                echo "<td>" . $row["problem_description"] . "</td>";
                echo "<td>" . $row["responsible_employee"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Нет заявок</td></tr>";
        }
        ?>
    </table>
    <a href="dashboard.php">Вернуться в панель управления</a>
</body>
</html>
