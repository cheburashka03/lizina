

<?php
// Начинаем сессию
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Обработка отправки формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST["login"];
    $password = $_POST["password"];

    // Подготовленный запрос для проверки учетных данных
    $stmt = $conn->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row["password"])) {
            // Успешная авторизация
            $_SESSION["user_id"] = $row["id"];
            $_SESSION["role"] = $row["role"];
            if ($row["role"] == "admin") {
                header("Location: admin.php");
            } elseif ($row["role"] == "masters") {
                header("Location: masters.php");
            } else {
                header("Location: users.php");
            }
            exit;
        } else {
            $error_message = "Неверный логин или пароль.";
        }
    } else {
        $error_message = "Неверный логин или пароль.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Страница входа</title>
</head>
<body>
    <h1>Страница входа</h1>
    <?php if (isset($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        Логин: <input type="text" name="login"><br><br>
        Пароль: <input type="password" name="password"><br><br>
        <input type="submit" name="submit" value="Войти">
    </form>
</body>
</html>
