<?php
// Начинаем сессию
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение списка заявок
$sql = "SELECT * FROM orders";
$orders_result = $conn->query($sql);

// Получение списка мастеров
$sql = "SELECT * FROM users WHERE role = 'masters'";
$masters_result = $conn->query($sql);

// Обработка назначения ответственного
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["assign_responsible"])) {
    $order_id = $_POST["order_id"];
    $master_id = $_POST["master_id"];
    $comment = $_POST["comment"];
    $parts_and_materials = $_POST["parts_and_materials"];

    $sql = "UPDATE orders SET responsible_employee = ?, comment = ?, parts_and_materials = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $master_id, $comment, $parts_and_materials, $order_id);
    if ($stmt->execute()) {
        // Добавление уведомления для мастера
        $sql = "INSERT INTO notifications (user_id, message, is_read) VALUES (?, ?, 0)";
        $message = "Вам назначена новая заявка. Номер заявки: " . $order["order_number"];
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $master_id, $message);
        $stmt->execute();
        $stmt->close();

        $success_message = "Заявка успешно назначена.";
    } else {
        $error_message = "Произошла ошибка при назначении заявки: " . $conn->error;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Панель администратора</title>
</head>
<body>
    <h1>Панель администратора</h1>
    <h2>Список заявок</h2>
    <table>
        <tr>
            <th>Номер заявки</th>
            <th>Этап</th>
            <th>Описание проблемы</th>
            <th>Ответственный</th>
            <th>Комментарий</th>
            <th>Запчасти и материалы</th>
            <th>Назначить ответственного</th>
        </tr>
        <?php
        if ($orders_result->num_rows > 0) {
            while($row = $orders_result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["order_number"] . "</td>";
                echo "<td>" . $row["stage"] . "</td>";
                echo "<td>" . $row["problem_description"] . "</td>";
                echo "<td>";
                if ($row["responsible_employee"] !== null) {
                    $sql = "SELECT login FROM users WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $row["responsible_employee"]);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $master = $result->fetch_assoc();
                    echo $master["login"];
                } else {
                    echo "Not assigned";
                }
                echo "</td>";
                echo "<td>" . $row["comment"] . "</td>";
                echo "<td>" . $row["parts_and_materials"] . "</td>";
                echo "<td>";
                echo "<form method='post' action='" . htmlspecialchars($_SERVER["PHP_SELF"]) . "'>";
                echo "<input type='hidden' name='order_id' value='" . $row["id"] . "'>";
                echo "<select name='master_id'>";
                echo "<option value=''>Select a master</option>";
                if ($masters_result->num_rows > 0) {
                    
                    while($master_row = $masters_result->fetch_assoc()) {
                        echo "<option value='" . $master_row["id"] . "'>" . $master_row["login"] . "</option>";
                    }
                }
                echo "</select>";
                echo "<input type='text' name='comment' placeholder='Comment'>";
                echo "<input type='text' name='parts_and_materials' placeholder='Parts and Materials'>";
                echo "<input type='submit' name='assign_responsible' value='Assign Responsible'>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No orders found.</td></tr>";
        }
        ?>
    </table>
    <?php if (isset($success_message)) { ?>
        <p style="color: green;"><?php echo $success_message; ?></p>
    <?php } ?>
    <?php if (isset($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>
    <a href="index.php">Logout</a>
</body>
</html>

