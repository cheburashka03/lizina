<?php
// Начинаем сессию
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Обработка отправки формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получение данных из формы
    $order_number = $_POST["order_number"];
    $date_added = date("Y-m-d H:i:s");
    $device_type = $_POST["device_type"];
    $model = $_POST["model"];
    $problem_description = $_POST["problem_description"];
    $client_name = $_POST["client_name"];
    $phone_number = $_POST["phone_number"];
    $status = "new";

    // Подготовленный запрос для добавления заявки
    $stmt = $conn->prepare("INSERT INTO orders (order_number, date_added, device_type, model, problem_description, client_name, phone_number, status, stage, responsible_employee) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssi", $order_number, $date_added, $device_type, $model, $problem_description, $client_name, $phone_number, $status, "in_progress", $_SESSION["user_id"]);

    if ($stmt->execute()) {
        $success_message = "Заявка успешно добавлена.";
    } else {
        $error_message = "Произошла ошибка при добавлении заявки: " . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Добавление заявки</title>
</head>
<body>
    <h1>Добавление заявки</h1>
    <?php if (isset($success_message)) { ?>
        <p style="color: green;"><?php echo $success_message; ?></p>
    <?php } ?>
    <?php if (isset($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        Номер заявки: <input type="text" name="order_number" required><br><br>
        Вид оргтехники: <input type="text" name="device_type" required><br><br>
        Модель: <input type="text" name="model" required><br><br>
        Описание проблемы: <textarea name="problem_description" required></textarea><br><br>
        ФИО клиента: <input type="text" name="client_name" required><br><br>
        Номер телефона: <input type="text" name="phone_number" required><br><br>
        <input type="submit" name="submit" value="Добавить заявку">
    </form>
    <a href="dashboard.php">Вернуться в панель управления</a>
</body>
</html>
