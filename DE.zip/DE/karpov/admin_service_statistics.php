<?php
// Начинаем сессию
session_start();

// Проверяем авторизацию пользователя
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit;
}

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение статистики
// Общее количество выполненных заявок
$sql = "SELECT COUNT(*) AS total_completed_orders FROM orders WHERE stage = 'ready_for_pickup'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $total_completed_orders = $result->fetch_assoc()["total_completed_orders"];
} else {
    $total_completed_orders = 0;
}

// Среднее время выполнения заявки
$sql = "SELECT AVG(TIMESTAMPDIFF(HOUR, creation_date, completion_date)) AS avg_completion_time FROM orders WHERE stage = 'ready_for_pickup'";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0) {
    $avg_completion_time = $result->fetch_assoc()["avg_completion_time"];
} else {
    $avg_completion_time = 0;
}

// Статистика по типам неисправностей
$sql = "SELECT problem_type, COUNT(*) AS count FROM orders GROUP BY problem_type";
$result = $conn->query($sql);
$problem_types = array();
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $problem_types[$row["problem_type"]] = $row["count"];
    }
} else {
    $problem_types = array();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Service Statistics</title>
</head>
<body>
    <h1>Admin Service Statistics</h1>
    <p>Total Completed Orders: <?php echo $total_completed_orders; ?></p>
    <p>Average Completion Time: <?php echo $avg_completion_time; ?> hours</p>
    <h2>Problem Types</h2>
    <ul>
        <?php foreach ($problem_types as $problem_type => $count) { ?>
            <li><?php echo $problem_type; ?>: <?php echo $count; ?></li>
        <?php } ?>
    </ul>
    <a href="index.php">Logout</a>
</body>
</html>


<!DOCTYPE html>
<html>
<head>
    <title>Статистика работы отдела обслуживания</title>
</head>
<body>
    <h1>Статистика работы отдела обслуживания</h1>
    <h2>Общие показатели</h2>
    <p>Количество выполненных заявок: <?php echo $total_completed_orders; ?></p>
    <p>Среднее время выполнения заявки: <?php echo round($avg_completion_time, 2); ?> часов</p>
    <h2>Статистика по типам неисправностей</h2>
    <table>
        <tr>
            <th>Тип неисправности</th>
            <th>Количество</th>
        </tr>
        <?php
        foreach ($problem_types as $problem_type => $count) {
            echo "<tr>";
            echo "<td>" . $problem_type . "</td>";
            echo "<td>" . $count . "</td>";
            echo "</tr>";
        }
        ?>
    </table>
    <a href="dashboard.php">Вернуться в панель управления</a>
</body>
</html>
