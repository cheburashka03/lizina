<?php
// Начинаем сессию
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение списка мастеров
$sql = "SELECT * FROM users WHERE role = 'masters'";
$masters_result = $conn->query($sql);

// Получение ID заявки из GET-параметра
$order_id = $_GET["id"];

// Получение данных о заявке
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

// Обработка отправки формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $master_id = $_POST["master_id"];
    $comment = $_POST["comment"];
    $parts_and_materials = $_POST["parts_and_materials"];

    // Обновление данных о заявке
    $stmt = $conn->prepare("UPDATE orders SET responsible_employee = ?, comment = ?, parts_and_materials = ? WHERE id = ?");
    $stmt->bind_param("sssi", $master_id, $comment, $parts_and_materials, $order_id);
    if ($stmt->execute()) {
        // Добавление уведомления для мастера
        $stmt = $conn->prepare("INSERT INTO notifications (user_id, message, is_read) VALUES (?, ?, 0)");
        $message = "Вам назначена новая заявка. Номер заявки: " . $order["order_number"];
        $stmt->bind_param("is", $master_id, $message);
        $stmt->execute();
        $stmt->close();

        $success_message = "Заявка успешно назначена.";
    } else {
        $error_message = "Произошла ошибка при назначении заявки: " . $conn->error;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Назначение ответственных</title>
</head>
<body>
    <h1>Назначение ответственных</h1>
    <?php if (isset($success_message)) { ?>
        <p style="color: green;"><?php echo $success_message; ?></p>
    <?php } ?>
    <?php if (isset($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=" . $order_id;?>">
        Номер заявки: <?php echo $order["order_number"]; ?><br><br>
        Описание проблемы: <?php echo $order["problem_description"]; ?><br><br>
        Ответственный: <select name="master_id">
            <option value="">Выберите мастера</option>
            <?php
            if ($masters_result->num_rows > 0) {
                while($row = $masters_result->fetch_assoc()) {
                    echo "<option value='" . $row["id"] . "'>" . $row["login"] . "</option>";
                }
            }
            ?>
        </select><br><br>
        Комментарий: <textarea name="comment"></textarea><br><br>
        Заказанные запчасти и материалы: <textarea name="parts_and_materials"></textarea><br><br>
        <input type="submit" name="submit" value="Назначить ответственного">
    </form>
    <a href="dashboard.php">Вернуться в панель управления</a>
</body>
</html>
