<?php
// Начинаем сессию
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demos";

$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение ID заявки из GET-параметра
$order_id = $_GET["id"];

// Получение данных о заявке
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

// Обработка отправки формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stage = $_POST["stage"];
    $problem_description = $_POST["problem_description"];
    $responsible_employee = $_POST["responsible_employee"];

    // Обновление данных о заявке
    $stmt = $conn->prepare("UPDATE orders SET stage = ?, problem_description = ?, responsible_employee = ? WHERE id = ?");
    $stmt->bind_param("ssii", $stage, $problem_description, $responsible_employee, $order_id);
    if ($stmt->execute()) {
        $success_message = "Заявка успешно обновлена.";
    } else {
        $error_message = "Произошла ошибка при обновлении заявки: " . $conn->error;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Редактирование заявки</title>
</head>
<body>
    <h1>Редактирование заявки</h1>
    <?php if (isset($success_message)) { ?>
        <p style="color: green;"><?php echo $success_message; ?></p>
    <?php } ?>
    <?php if (isset($error_message)) { ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php } ?>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?id=" . $order_id;?>">
        Номер заявки: <?php echo $order["order_number"]; ?><br><br>
        Этап: <select name="stage">
            <option value="in_progress" <?php if ($order["stage"] == "in_progress") echo "selected"; ?>>В процессе ремонта</option>
            <option value="ready_for_pickup" <?php if ($order["stage"] == "ready_for_pickup") echo "selected"; ?>>Готова к выдаче</option>
            <option value="waiting_for_parts" <?php if ($order["stage"] == "waiting_for_parts") echo "selected"; ?>>Ожидание запчастей</option>
        </select><br><br>
        Описание проблемы: <textarea name="problem_description"><?php echo $order["problem_description"]; ?></textarea><br><br>
        Ответственный исполнитель: <input type="text" name="responsible_employee" value="<?php echo $order["responsible_employee"]; ?>"><br><br>
        <input type="submit" name="submit" value="Обновить заявку">
    </form>
    <a href="dashboard.php">Вернуться в панель управления</a>
</body>
</html>
